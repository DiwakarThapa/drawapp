//
//  ViewController.swift
//  ekbanaRealmSynsApp
//
//  Created by Diwakar Thapa on 10/2/18.
//  Copyright © 2018 Cloudouse. All rights reserved.
//

import UIKit
import RealmSwift
import Realm


class ViewController: UIViewController {
    var intialPoint = CGPoint.zero
    var token: NotificationToken!
    var configuration: Realm.Configuration!
    static var lineWidth:CGFloat = 3.0
    static var lineStokeColor:CGColor = UIColor.red.cgColor
    static var hexcode:String = "#FF0000"
    @IBOutlet weak var btnChangeLineProperty: UIButton!
    var grealm:Realm = try! Realm()
    var serverRelam:Realm?
    var swiped: Bool = false
    var attempt: String = UUID().uuidString
    // [deviceId: (attempt, lastPoint)]
    var pathPoint: [String: (String, CGPoint)] = [:]
    var lastpoint:CGPoint = CGPoint.zero
    var deviceID:String?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupRealm()
        deviceID = UserDefaults.standard.string(forKey: "deviceId")
    }
    

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.swiped = false
        if let touchesPoint = touches.first {
            self.lastpoint = touchesPoint.location(in: self.view)
            try! self.serverRelam?.write {
                let drawPoint = self.convert(point: self.lastpoint, attempt: self.attempt)
                self.serverRelam?.add(drawPoint)
            }
        }
        
    }
    
    func convert(point: CGPoint, attempt: String) -> Drawpoint{
        let drawpt = Drawpoint()
        drawpt.x = point.x
        drawpt.y = point.y
        drawpt.color = ViewController.hexcode
        drawpt.width = "\(ViewController.lineWidth)"
        drawpt.attempt = attempt
        return drawpt
    }
    
    func convertDrawPoint(_ point: Drawpoint) -> CGPoint {
        return CGPoint(x: point.x, y: point.y)
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.swiped = true
        if let touchesPoint = touches.first{
            let currentPoint = touchesPoint.location(in: self.view)
            try! self.serverRelam?.write{
                let drawPoint = self.convert(point: currentPoint, attempt: self.attempt)
                self.serverRelam?.add(drawPoint)
            }
            self.drawtheLine(from:lastpoint, to:currentPoint)
            self.lastpoint = currentPoint
        }
        
    }
    
    @IBAction func btnChangeLineProperty(_ sender: UIButton) {
        let LinePropertyViewController = storyboard?.instantiateViewController(withIdentifier: "LinePropertyViewController") as? LinePropertyViewController
        
        present(LinePropertyViewController!, animated: true, completion: nil)
    }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        attempt = UUID().uuidString
    }
    
    private func setupRealm() {
        
        let serverURL = URL(string: "https://generic-steel-mouse.us1.cloud.realm.io")!
        let credentials = SyncCredentials.usernamePassword(username: "admin", password: "admin")
        SyncUser.logIn(with: credentials, server: serverURL) { (user, error) in
            if let user = user{
                let synURL = URL(string: "realms://generic-steel-mouse.us1.cloud.realm.io/~/drawapp")
                DispatchQueue.main.async {
                    // Open Realm
                    self.configuration = Realm.Configuration(
                        syncConfiguration: SyncConfiguration(user: user, realmURL: synURL!))
                    self.serverRelam = try! Realm(configuration: self.configuration)
                    let drawpointFromRealm = self.serverRelam?.objects(Drawpoint.self)
                
                    //new user added in between..............
                    drawpointFromRealm?.forEach({
                        self.draw(point: $0)
                    })
                    
                    self.token = drawpointFromRealm?.observe({ (changes) in
                        switch changes{
                        case .initial:
                            break
                        case .update(_, deletions: let deletion, insertions: let insert, modifications: let modification):
                            insert.forEach({ (index) in
                                guard let point = drawpointFromRealm?[index] else {return}
                                self.draw(point: point)
                      })
                            break
                        case .error(let error):
                            print("\(error)")
                        }
                        
                        
                    })
                }
                
            }else if let error = error{
                debugPrint(error)
            }
        }
    }
    
    func draw(point: Drawpoint) {
        let currentPoint = self.convertDrawPoint(point)
        if point.deviceId != self.deviceID{
        if let attempt = self.pathPoint[point.deviceId]{
            if attempt.0 == point.attempt{
                self.drawtheLinei(from: attempt.1, to: currentPoint, strokeColor: UIColor.init(hexString: point.color!).cgColor, lineWidth: CGFloat((point.width! as NSString).floatValue))
             }
            
        }
        self.pathPoint[point.deviceId] = (point.attempt, currentPoint)
        }
        
    }
    
    
    
    func  drawtheLine(from: CGPoint, to: CGPoint) {
        let drawLine = UIBezierPath()
        drawLine.move(to: CGPoint(x: from.x , y: from.y))
        drawLine.addLine(to: CGPoint(x: to.x , y: to.y))
        let shapeLayer = CAShapeLayer()
        shapeLayer.path = drawLine.cgPath
        shapeLayer.strokeColor = ViewController.lineStokeColor
        shapeLayer.lineWidth = ViewController.lineWidth
        shapeLayer.lineCap = .round
        self.view.layer.addSublayer(shapeLayer)
    }
    func  drawtheLinei(from: CGPoint, to: CGPoint,strokeColor:CGColor,lineWidth:CGFloat){
        var drawLine = UIBezierPath()
        var shapeLayer = CAShapeLayer()
        drawLine.move(to: CGPoint(x: from.x , y: from.y))
        drawLine.addLine(to: CGPoint(x: to.x , y: to.y))
        shapeLayer.path = drawLine.cgPath
        shapeLayer.strokeColor = strokeColor
        shapeLayer.lineWidth = lineWidth
        shapeLayer.lineCap = .round
        self.view.layer.addSublayer(shapeLayer)
        
    }
   
    
    deinit {
        self.token?.invalidate()
    }
    
    
    
}

