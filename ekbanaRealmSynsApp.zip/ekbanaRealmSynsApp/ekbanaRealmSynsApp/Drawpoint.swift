//
//  Drawpoint.swift
//  ekbanaRealmSynsApp
//
//  Created by Diwakar Thapa on 10/2/18.
//  Copyright © 2018 Cloudouse. All rights reserved.
//

var myDeviceId: String {
    if let id = UserDefaults.standard.string(forKey: "deviceId") {
        return id
    }
    let id = UUID().uuidString
    UserDefaults.standard.set(id, forKey: "deviceId")
    return id
}

import Foundation
import Realm
import RealmSwift

class Drawpoint:Object {
    @objc dynamic var id = UUID().uuidString
    @objc dynamic var deviceId: String = myDeviceId
    @objc dynamic var attempt: String = ""
    @objc dynamic var x = CGFloat(0)
    @objc dynamic var y = CGFloat(0)
    @objc dynamic var color:String?
    @objc dynamic var width:String?
//    func generateID(ServerRealm:Realm) -> Int{
//        return (ServerRealm.objects(Drawpoint.self).max(ofProperty: "id") as Int? ?? 0) + 1
//    }
       // var drawptn = List<Drawpoint>()
//    func add(Point:CGPoint)  {
//        let realm = try! Realm()
//        try! realm.write{
//            if (drawpath?.isInvalidated)!{
//                drawpath = DrawPath()
//                drawpath?.datapoint?.x = Point.x
//                drawpath?.datapoint?.y = Point.y
//                realm.add(drawpath!)
//            }
//        }
//    }
}
