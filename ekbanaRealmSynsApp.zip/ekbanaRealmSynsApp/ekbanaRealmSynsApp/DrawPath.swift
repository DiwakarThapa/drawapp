//
//  DrawPath.swift
//  ekbanaRealmSynsApp
//
//  Created by Diwakar Thapa on 10/2/18.
//  Copyright © 2018 Cloudouse. All rights reserved.
//

import Foundation
import Realm
import RealmSwift

class DrawPath:Object{
    @objc dynamic var id: String = UUID().uuidString
 
    var point = List<Drawpoint>()
   // @objc dynamic var drawpnt:[Drawpoint]?
    
    override open class func primaryKey() -> String? {
        return "id"
    }
}

