//
//  LinePropertyViewController.swift
//  ekbanaRealmSynsApp
//
//  Created by Diwakar Thapa on 10/16/18.
//  Copyright © 2018 Cloudouse. All rights reserved.
//

import UIKit
import ChromaColorPicker
class LinePropertyViewController: UIViewController,ChromaColorPickerDelegate{
    
    
    @IBOutlet weak var thicknessSlider: UISlider!
    let size:CGSize = CGSize(width: 450, height: 280)
    var color:CGColor? = nil
    var thickness:CGFloat? = nil
    var hexColor:String = "#FF0000"
    override func viewDidLoad() {
        super.viewDidLoad()
       self.displayColorPicker()
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        self.thicknessSlider.value = Float(ViewController.lineWidth)
    }
    func displayColorPicker()  {
        let colorPicker = ChromaColorPicker(frame: CGRect(x:20, y: self.view.frame.height / 2 - 150, width: 300, height: 280))
        colorPicker.delegate = self
        colorPicker.stroke = 3
        colorPicker.padding = 10
        colorPicker.hexLabel.textColor = UIColor.black
         self.view.addSubview(colorPicker)
        let displayLabel = UILabel(frame: CGRect(x:  55, y: colorPicker.frame.height + 35, width: 300, height: 25))
        displayLabel.text = "Press + button to select color"
        displayLabel.baselineAdjustment = .alignCenters
        self.view.addSubview(displayLabel)
    }
    func colorPickerDidChooseColor(_ colorPicker: ChromaColorPicker, color: UIColor) {
        self.color = UIColor.init(hexString: colorPicker.hexLabel.text!).cgColor
        self.hexColor = colorPicker.hexLabel.text!
    }
   
    @IBAction func viewDismiss(_ sender: UIButton) {
        self.dismiss(animated: true) {
           
            if let color = self.color{
               ViewController.lineStokeColor = color
                ViewController.hexcode = self.hexColor
            }
            if let lineWidth = self.thickness{
                ViewController.lineWidth = lineWidth
            }
            
        }
    }
    
    @IBAction func sliderChanged(_ sender: UISlider) {
      self.thickness = CGFloat(sender.value)
        
    }
    
}
